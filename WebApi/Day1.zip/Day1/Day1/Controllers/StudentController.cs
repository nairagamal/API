﻿using Day1.Entity;
using Day1.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Day1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly CompanyContext std;
        public StudentController(CompanyContext _std)
        {
            std = _std;
        }
        [HttpGet]
        public IActionResult GetAll()
        {
            var student = std.Students.ToList();
            if(student is null)
            {
                return NotFound();
            }
            return Ok(student);

        }
        [HttpGet]
        [Route("{id}")]
        public IActionResult GetbyId(int id)
        {
            var student = std.Students.Find(id);
            if (student is null)
            {
                return NotFound(new {msg=$"student with id {id} is not found "});
            }
            return Ok(new { msg = $"Student with id {id} is found", student = student});
        }
        [HttpGet]
        [Route("GetByName/{name}")]
        public IActionResult GetByName(string name)
        {
            var student = std.Students.FirstOrDefault(s => s.Name == name);

            if (student == null)
            {
                return NotFound(new { msg = $"Student with name {name} is not found" });
            }

            return Ok(new { msg = $"Student with name {name} is found", student = student });
        }


        
        [HttpPost]
        public IActionResult Add([FromBody] Student newStudent)
        {
            if (newStudent == null)
            {
                return BadRequest(new { msg = "Invalid student data" });
            }

            std.Students.Add(newStudent);
            std.SaveChanges();

            return CreatedAtAction(nameof(GetbyId), new { id = newStudent.Id }, 
                new { msg = "Student added successfully", student = newStudent });
        }

        [HttpPut]
        [Route("{id}")]
        public IActionResult Edit(int id, [FromBody] Student updatedStudent)
        {
            if (updatedStudent == null || id != updatedStudent.Id)
            {
                return BadRequest(new { msg = "Invalid student data or ID mismatch" });
            }

            var existingStudent = std.Students.Find(id);

            if (existingStudent == null)
            {
                return NotFound(new { msg = $"Student with ID {id} not found" });
            }

            existingStudent.Name = updatedStudent.Name;
            existingStudent.Age = updatedStudent.Age;
            // Update other properties as needed

            std.SaveChanges();

            return Ok(new { msg = $"Student with ID {id} updated successfully", student = existingStudent });
        }

        [HttpDelete]
        [Route("{id}")]
        public IActionResult Delete(int id)
        {
            var studentToDelete = std.Students.Find(id);

            if (studentToDelete == null)
            {
                return NotFound(new { msg = $"Student with ID {id} not found" });
            }

            std.Students.Remove(studentToDelete);
            std.SaveChanges();

            return Ok(new { msg = $"Student with ID {id} deleted successfully" });
        }


        //public IActionResult Edit(int id)
        //{
        //}
        //public IActionResult Delete(int id) { }
    }
}
